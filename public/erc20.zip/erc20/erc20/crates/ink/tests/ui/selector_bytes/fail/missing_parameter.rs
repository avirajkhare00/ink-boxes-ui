const _: u32 = ink::selector_bytes!();

fn main() {}

const _: u32 = ink::selector_bytes!(true);

fn main() {}

const _: u32 = ink::selector_id!();

fn main() {}

#![no_implicit_prelude]

const _: [::core::primitive::u8; 32] = ::ink::blake2x256!("test");

fn main() {}

const INPUT: &str = "test";
const _: u32 = ink::selector_id!(INPUT);

fn main() {}

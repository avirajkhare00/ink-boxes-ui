#![no_implicit_prelude]

const _: ::core::primitive::u32 = ::ink::selector_id!("test");

fn main() {}

const _: u32 = ink::selector_bytes!(42);

fn main() {}

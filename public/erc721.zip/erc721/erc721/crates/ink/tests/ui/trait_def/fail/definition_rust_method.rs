#[ink::trait_definition]
pub trait TraitDefinition {
    fn rust_method(&self);
}

fn main() {}

const _: [u8; 32] = ink::blake2x256!(true);

fn main() {}

#![no_implicit_prelude]

const _: [::core::primitive::u8; 4] = ::ink::selector_bytes!("test");

fn main() {}

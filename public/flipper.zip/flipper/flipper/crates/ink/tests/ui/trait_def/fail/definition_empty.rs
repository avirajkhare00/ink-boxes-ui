#[ink::trait_definition]
pub trait TraitDefinition {}

fn main() {}

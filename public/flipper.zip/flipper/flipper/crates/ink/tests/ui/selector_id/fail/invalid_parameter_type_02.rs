const _: u32 = ink::selector_id!(42);

fn main() {}

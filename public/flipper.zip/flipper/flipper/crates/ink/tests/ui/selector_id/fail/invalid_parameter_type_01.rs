const _: u32 = ink::selector_id!(true);

fn main() {}

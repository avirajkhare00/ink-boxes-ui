const INPUT: &str = "test";
const _: u32 = ink::selector_bytes!(INPUT);

fn main() {}
